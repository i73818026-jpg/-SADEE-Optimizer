# SADEE Optimizer

Android optimizer starter app built with Kotlin + Jetpack Compose.

## GitHub APK build
1. Create a GitHub repository.
2. Upload this project with all folders/files.
3. Push to the `main` branch.
4. Open **Actions** → **Build APK**.
5. Open the successful workflow run → **Artifacts** → `sadee-optimizer-debug-apk`.

The artifact contains `app-debug.apk`.
